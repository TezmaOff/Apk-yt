package com.tezma.autotube

import android.app.*
import android.os.*
import android.content.*
import android.graphics.Color
import android.text.InputType
import android.view.View
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefsName = "tezma_autotube_config"
    private lateinit var result: TextView

    private fun makeEdit(hintText: String, value: String = "", password: Boolean = false): EditText {
        return EditText(this).apply {
            hint = hintText
            setText(value)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setSingleLine(false)
            if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showMainScreen()
    }

    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(18, 18, 28))
        }
    }

    private fun title(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 26f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 18)
        }
    }

    private fun smallText(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 8)
        }
    }

    private fun showMainScreen() {
        val prefs = getSharedPreferences(prefsName, MODE_PRIVATE)
        val layout = baseLayout()
        val serverUrl = makeEdit("URL serveur ex: http://10.0.2.2:8000/generate-video", prefs.getString("server_url", "http://10.0.2.2:8000/generate-video") ?: "")
        val niche = makeEdit("Niche ex: histoire de France", "histoire de France")
        val topic = makeEdit("Sujet vidéo", "un fait historique incroyable")
        val style = makeEdit("Style ex: sombre, mystérieux", "mystérieux, accrocheur, simple")
        val upload = CheckBox(this).apply { text = "Uploader sur YouTube en privé"; setTextColor(Color.WHITE) }
        val btnConfig = Button(this).apply { text = "Configuration API" }
        val btn = Button(this).apply { text = "Créer la vidéo" }
        result = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; setPadding(0, 16, 0, 0) }

        layout.addView(title("Tezma AutoTube AI"))
        layout.addView(smallText("Version Android avec entrée de clés API. Les clés restent dans le téléphone et sont envoyées au serveur seulement au moment de générer."))
        layout.addView(serverUrl)
        layout.addView(niche)
        layout.addView(topic)
        layout.addView(style)
        layout.addView(upload)
        layout.addView(btnConfig)
        layout.addView(btn)
        layout.addView(result)
        setContentView(ScrollView(this).apply { addView(layout) })

        btnConfig.setOnClickListener { showConfigScreen() }
        btn.setOnClickListener {
            prefs.edit().putString("server_url", serverUrl.text.toString()).apply()
            generateVideo(serverUrl.text.toString(), niche.text.toString(), topic.text.toString(), style.text.toString(), upload.isChecked)
        }
    }

    private fun showConfigScreen() {
        val prefs = getSharedPreferences(prefsName, MODE_PRIVATE)
        val layout = baseLayout()
        val openAi = makeEdit("OPENAI_API_KEY", prefs.getString("openai_key", "") ?: "", true)
        val eleven = makeEdit("ELEVENLABS_API_KEY", prefs.getString("eleven_key", "") ?: "", true)
        val voice = makeEdit("ELEVENLABS_VOICE_ID", prefs.getString("voice_id", "") ?: "")
        val ytToken = makeEdit("YOUTUBE_TOKEN_JSON optionnel", prefs.getString("yt_token_json", "") ?: "")
        val save = Button(this).apply { text = "Sauvegarder" }
        val clear = Button(this).apply { text = "Effacer les clés" }
        val back = Button(this).apply { text = "Retour" }
        val info = smallText("Ne colle pas tes clés dans le code. Elles sont stockées dans les préférences privées de l’application. Pour YouTube, le plus simple reste de connecter OAuth côté serveur au premier lancement.")

        layout.addView(title("Configuration API"))
        layout.addView(info)
        layout.addView(openAi)
        layout.addView(eleven)
        layout.addView(voice)
        layout.addView(ytToken)
        layout.addView(save)
        layout.addView(clear)
        layout.addView(back)
        setContentView(ScrollView(this).apply { addView(layout) })

        save.setOnClickListener {
            prefs.edit()
                .putString("openai_key", openAi.text.toString())
                .putString("eleven_key", eleven.text.toString())
                .putString("voice_id", voice.text.toString())
                .putString("yt_token_json", ytToken.text.toString())
                .apply()
            Toast.makeText(this, "Clés sauvegardées", Toast.LENGTH_SHORT).show()
        }
        clear.setOnClickListener {
            prefs.edit().remove("openai_key").remove("eleven_key").remove("voice_id").remove("yt_token_json").apply()
            openAi.setText(""); eleven.setText(""); voice.setText(""); ytToken.setText("")
            Toast.makeText(this, "Clés effacées", Toast.LENGTH_SHORT).show()
        }
        back.setOnClickListener { showMainScreen() }
    }

    private fun generateVideo(serverUrl: String, niche: String, topic: String, style: String, upload: Boolean) {
        val prefs = getSharedPreferences(prefsName, MODE_PRIVATE)
        result.text = "Génération en cours..."
        Thread {
            try {
                val body = JSONObject().apply {
                    put("niche", niche)
                    put("topic", topic)
                    put("style", style)
                    put("duration_seconds", 60)
                    put("upload_youtube", upload)
                    put("privacy_status", "private")
                    put("openai_api_key", prefs.getString("openai_key", ""))
                    put("elevenlabs_api_key", prefs.getString("eleven_key", ""))
                    put("elevenlabs_voice_id", prefs.getString("voice_id", ""))
                    put("youtube_token_json", prefs.getString("yt_token_json", ""))
                }
                val conn = URL(serverUrl).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().readText()
                runOnUiThread { result.text = response }
            } catch (e: Exception) {
                runOnUiThread { result.text = "Erreur: ${e.message}" }
            }
        }.start()
    }
}
